import os

import pywebio
import pywebio.output as output
import pywebio.input as input

from api_element import APIProcessor

current_workspace = os.path.join(os.path.dirname(os.path.abspath(__file__)))


def main():
    output.put_markdown('# API Tool')
    output.put_markdown('Features：')
    output.put_markdown("""
- Choose api test cases excel
- Call the apis automatically
    """)
    content = open(os.path.join(current_workspace, 'sample.xlsx'), 'rb').read()
    output.put_file(name='template.xlsx', content=content, label='Download Template File')

    file = input.file_upload('Choose an excel file', '.xlsx')

    # df_config = pd.read_excel(file['content'], sheet_name='Config', dtype=str)
    # output.put_html(df_config.head(10).to_html())
    with output.put_loading(shape='border', color='dark'):
        api_processor = APIProcessor(file['content'])
        api_processor.run_apis()


if __name__ == '__main__':
    pywebio.start_server(main, port=8080, debug=True, cdn=False, auto_open_webbrowser=True)

    # output.put_processbar(name='counts', init=1, label='counts', auto_close=True)
    # put_processbar('bar');
    # for i in range(1, 11):
    #     set_processbar('bar', i / 10)
    #     time.sleep(0.1)
