from cmutils.log import Logger

logger = Logger(logfile_path=f'api-tools.log')
logger = logger.logger
