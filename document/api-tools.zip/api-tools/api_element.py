import json
import logging
import time
import pandas as pd
import requests

# from cmutils.log import logger
from pywebio.output import put_loading, put_info, put_warning, put_error, put_success, put_table, put_link, put_tabs, \
    put_markdown, put_code, put_text

from cmutils.log import Logger
from utils import logger

TCID = 'TCID'
DESCRIPTION = 'Description'
REQUEST_TEMPLATE = 'Request Template'
REQUEST_METHOD = 'Request Method'
RESPONSE_CODE = 'Response Code'
REQUEST_BODY = 'Request Body'
URL = 'URL'


class APITemplate:
    def __init__(self, request_template, request_method, url, request_body):
        self.request_template = request_template
        self.request_method = request_method
        self.url = url
        self.request_body = request_body


class APITestCase:
    MANDATORY_FIELDS = [TCID, DESCRIPTION, REQUEST_TEMPLATE, RESPONSE_CODE]

    def __init__(self, tcid, description, request_template, response_code, parameter_map):
        self.tcid = tcid
        self.description = description
        self.request_template = request_template
        self.response_code = response_code
        self.parameter_map = parameter_map
        # print(parameter_map)


class APIRequest:
    env = ''
    host = 'localhost'
    headers = {'Content-Type': 'application/json'}
    params = {}
    POST = 'POST'
    GET = 'GET'

    def __init__(self, env, host, headers={}, params={}):
        self.env = env
        self.host = host

        headers = json.loads(headers) if type(headers) == str else headers
        params = json.loads(params) if type(params) == str else params

        self.headers = {**self.headers, **headers}
        self.params = {**self.params, **params}

    def call(self, url, method, data, headers={}, params={}):
        headers = json.loads(headers) if type(headers) == str else headers
        params = json.loads(params) if type(params) == str else params
        data = data if type(data) == str else json.dumps(data)
        methods = {
            self.GET: self.get,
            self.POST: self.post,
        }
        logger.info(''.join([url, '>', method, '>', str(data), '>', str(headers), '>', str(params)]))

        return methods[method](url, data, headers, params)

    def post(self, url, data, headers=None, params=None):
        # requests.post('https://api.github.com/some/endpoint', data=json.dumps({'some': 'data'}))
        print(f'{self.host}{url}')
        return requests.post(f'{self.host}{url}', data=data, headers=headers, params=params)

    def get(self, url, data, headers={}, params={}):
        headers = headers if headers else self.headers
        params = params if params else self.params
        return requests.get(f'{self.host}{url}', data=data, headers=headers, params=params)


def prepare_request_data(request_body, parameter_map):
    for key, value in parameter_map.items():
        request_body = str(request_body).replace(str(key), str(value))
    return request_body


def put_result_tab(tcid, description, request_data, response_data, error_info=None):
    tabs = []
    tabs.append({'title': 'TCID', 'content': tcid})
    tabs.append({'title': 'Description', 'content': description})
    tabs.append({'title': 'Request Data', 'content': put_code(request_data, language='json')})
    tabs.append({'title': 'Response Data', 'content': put_code(response_data, language='json')})
    if error_info:
        tabs.append({'title': 'Markdown', 'content': put_text(error_info).style('color:red')})
    else:
        pass
    put_tabs(tabs=tabs)

class APIProcessor:

    def __init__(self, io_excel):
        # io = pd.io.excel.ExcelFile('./sample.xlsx')
        self.df_test_cases = pd.read_excel(io_excel, sheet_name='Test Cases', dtype=str)
        self.df_api_template = pd.read_excel(io_excel, sheet_name='API Template', dtype=str)
        self.df_config = pd.read_excel(io_excel, sheet_name='Config', dtype=str)

        self.df_test_cases = self.df_test_cases.where(self.df_test_cases.notnull(), '')
        self.df_api_template = self.df_api_template.where(self.df_api_template.notnull(), '')
        self.df_config = self.df_config.where(self.df_config.notnull(), '')

        self.config_map = {}
        self.test_case_list = []
        self.api_template_map = {}

        for index, row in self.df_api_template.iterrows():
            # print(row)
            template = APITemplate(row[REQUEST_TEMPLATE], row[REQUEST_METHOD], row[URL], row[REQUEST_BODY])
            self.api_template_map[row[REQUEST_TEMPLATE]] = template

        for index, row in self.df_test_cases.iterrows():
            # print(index, '---', row)
            # print(row.keys())
            parameter_map = {}
            for key in row.keys():
                if key not in APITestCase.MANDATORY_FIELDS:
                    parameter_map[key] = row[key]

            testcase = APITestCase(row[TCID], row[DESCRIPTION], row[REQUEST_TEMPLATE], row[RESPONSE_CODE],
                                   parameter_map)
            self.test_case_list.append(testcase)

        for index, row in self.df_config.iterrows():
            self.config_map[row['Key']] = row['Value']

    def run_apis(self):

        api_request = APIRequest(self.config_map['Environment'], self.config_map['Host'], self.config_map['Headers'])

        for test_case in self.test_case_list:
            test_case.request_template
            template_name = test_case.request_template
            template = self.api_template_map[template_name]
            request_data = prepare_request_data(template.request_body, test_case.parameter_map)
            request_url = prepare_request_data(template.url, test_case.parameter_map)
            response = api_request.call(request_url, template.request_method, request_data)
            response_json = response.text
            logger.info(response.status_code)
            if str(response.status_code) == str(test_case.response_code):
                logger.info('Post Successfully!')
                # put_info('this is info message!')
                # put_warning('this is warning message!')
                put_success(f"{template.request_method} {self.config_map['Host']}{request_url} {response.status_code}")
                put_result_tab(test_case.tcid, test_case.description, request_data, response_json)
            else:
                logger.error('Post Failed!')
                put_error(f"{template.request_method} {self.config_map['Host']}{request_url} {response.status_code}")
                put_result_tab(test_case.tcid, test_case.description, request_data, response_json)
            time.sleep(1)
        # assert()
        # exit()




