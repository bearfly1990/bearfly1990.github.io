import configparser
import glob
import os

import pandas as pd

pd.io.formats.excel.ExcelFormatter.header_style = None

CONFIG_PATH = './config.ini'


class Config:
    def __init__(self):
        cf = configparser.ConfigParser()
        cf.read(CONFIG_PATH)

        self.folder = cf.get("config", "folder")
        self.sep = cf.get("config", "sep")
        self.header = True if int(cf.get("config", "header")) == 1 else False
        self.output = cf.get("config", "output")


def read_csvs(config):
    folder = config.folder
    csv_file_paths = glob.glob(f"{folder}/*.csv", recursive=True)
    if not csv_file_paths:
        print('No csv files found, please check the config!')
        exit()
    with pd.ExcelWriter(config.output, engine="openpyxl") as writer:
        for csv_file_path in csv_file_paths:
            print(f'reading {csv_file_path}')
            df = pd.read_csv(csv_file_path, sep=config.sep, engine='python', header=0 if config.header else None)

            filename = os.path.splitext(os.path.basename(csv_file_path))[0]

            df.to_excel(writer, sheet_name=filename, index=None, header=True if config.header else None)
    print(f'write to {config.output} done')


if __name__ == '__main__':
    config = Config()
    read_csvs(config)
